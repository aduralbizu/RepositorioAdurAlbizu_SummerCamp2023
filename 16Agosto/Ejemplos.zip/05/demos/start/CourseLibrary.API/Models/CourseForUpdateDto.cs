﻿namespace CourseLibrary.API.Models;

public class CourseForUpdateDto
{
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
}