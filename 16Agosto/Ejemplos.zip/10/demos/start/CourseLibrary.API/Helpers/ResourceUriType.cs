﻿namespace CourseLibrary.API.Helpers;

public enum ResourceUriType
{
    PreviousPage,
    NextPage
}
