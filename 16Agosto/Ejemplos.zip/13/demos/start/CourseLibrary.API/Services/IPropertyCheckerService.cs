﻿namespace CourseLibrary.API.Services;
public interface IPropertyCheckerService
{
    bool TypeHasProperties<T>(string? fields);
}
