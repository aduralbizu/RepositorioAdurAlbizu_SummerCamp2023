﻿namespace CourseLibrary.API.Services;

public interface IPropertyMapping
{
}